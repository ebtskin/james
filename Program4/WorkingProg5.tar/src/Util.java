import java.util.Scanner;

public class Util {

	protected Scanner input;
	
	Util()
	{
		input = new Scanner(System.in);
	}
}

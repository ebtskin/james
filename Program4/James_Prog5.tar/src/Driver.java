public class Driver
{
	protected Vertex[] vertex_list; //Create the vertex of restaurant name
	protected int max; //Max vertex size for testing purpose
	
	//Constructor to pass up the Vertex store name and driver info
	Driver(String driver_name, String storeName, int miles_from) 
	{
		add(driver_name, storeName, miles_from); // call the add function to create a new vertex and add to adjacency list. 
		this.max = 10; //For testing purpose
		this.vertex_list = new Vertex[max]; //For testing I'm just setting a max size of restaurant 
		
		for(int i = 0; i < 10; ++i) //Set all the vertex to null;
			vertex_list[i] = null;
		
	}
	
	//This function will select the nearest driver that's not busy from the restaurant adjacency LLL. 
	public void select_driver(String storeName)
	{
		for(int i = 0; i < max; ++i)
		{
			if(vertex_list[i] == null)
				return;
			
			else if(vertex_list[i].biz_name.compareTo(storeName) == 0)
			{
				while(vertex_list[i].head != null)
				{
					if(vertex_list[i].head.not_busy == false)
					{
						System.out.println("I found the driver");
					}
				}
					
			}
			++i;	
		}
	}
	
	//This function will either add a new restaurant and driver or only a driver if the restaurant already exist. 
	public void add(String driver_name, String storeName, int miles_from)
	{
		
		for (int i = 0; i < 10; ++i)
		{
			if(vertex_list[i] == null)
			{
				vertex_list[i] = new Vertex(driver_name, storeName, miles_from);
				return;
			}
			else
			{
				if(vertex_list[i].biz_name.compareTo(storeName) == 0)
				{
					vertex_list[i].add_vertex_node(driver_name, miles_from);
					return;
				}
			}
		}
		System.out.println("List is full!");
	}

	public void display()
	{
		
	}
}